# disabledActionButtons
Disable the form action buttons typically found in the bottom right of the editor.

## Usage
```javascript
var options = {
      disabledActionButtons: ['data']
    };
$(container).formBuilder(options);
```
## See it in Action
<p data-height="525" data-theme-id="22927" data-embed-version="2" data-slug-hash="JNYvKQ" data-default-tab="result" data-user="kevinchappell" class="codepen"></p>
