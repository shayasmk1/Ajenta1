# Tabbed/Multi-Page Forms

In some cases you need to provide a ui where users can create multiple form templates at the same time. This is especially useful for multi-page forms. The example below uses jQuery-ui Tabs.
<p data-height="650" data-theme-id="22927" data-slug-hash="BKYPRp" data-default-tab="result" data-user="kevinchappell" class="codepen"></p>
